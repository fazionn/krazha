const sectors = [
  { color: "#a1e191", text: "#333333", label: "1.2x", probability: 0.1 },
  { color: "#434049", text: "#eeffe7", label: "5x", probability: 0.2 },
  { color: "#a1e191", text: "#333333", label: "0.01x", probability: 0.15 },
  { color: "#434049", text: "#eeffe7", label: "0.5x", probability: 0.1 },
  { color: "#a1e191", text: "#333333", label: "1.2x", probability: 0.1 },
  { color: "#434049", text: "#eeffe7", label: "You lose", probability: 0.05 },
  { color: "#a1e191", text: "#333333", label: "1000x", probability: 0.05 },
  { color: "#434049", text: "#eeffe7", label: "0.5x", probability: 0.05 },
  { color: "#a1e191", text: "#333333", label: "0.9x", probability: 0.1 },
  { color: "#434049", text: "#eeffe7", label: "2x", probability: 0.1 },
];

const events = {
  listeners: {},
  addListener: function (eventName, fn) {
    this.listeners[eventName] = this.listeners[eventName] || [];
    this.listeners[eventName].push(fn);
  },
  fire: function (eventName, ...args) {
    if (this.listeners[eventName]) {
      for (let fn of this.listeners[eventName]) {
        fn(...args);
      }
    }
  },
};

const rand = (m, M) => Math.random() * (M - m) + m;
const tot = sectors.length;
const spinEl = document.querySelector("#spin");
const ctx = document.querySelector("#wheel").getContext("2d");
const dia = ctx.canvas.width;
const rad = dia / 2;
const PI = Math.PI;
const TAU = 2 * PI;
const arc = TAU / sectors.length;

const friction = 0.991; // 0.995=soft, 0.99=mid, 0.98=hard
let angVel = 0; // Angular velocity
let ang = 0; // Angle in radians

let spinButtonClicked = false;

const getIntervals = () => {
  const intervals = [];
  let total = 0;

  sectors.forEach(sector => {
    total += sector.probability;
    intervals.push(total);
  });

  return intervals;
};

const getIndex = () => {
  const normalizedAngle = (ang % TAU + TAU) % TAU;
  return Math.floor((normalizedAngle + (PI / 2)) / arc) % tot;
};

function drawSector(sector, i) {
  const startAngle = arc * i;
  const endAngle = startAngle + arc;
  ctx.save();
  
  ctx.beginPath();
  ctx.fillStyle = sector.color;
  ctx.moveTo(rad, rad);
  ctx.arc(rad, rad, rad, startAngle, endAngle);
  ctx.lineTo(rad, rad);
  ctx.fill();
  
  ctx.translate(rad, rad);
  ctx.rotate(startAngle + arc / 2);
  ctx.textAlign = "right";
  ctx.fillStyle = sector.text;
  ctx.font = "bold 30px 'Lato', sans-serif";
  ctx.fillText(sector.label, rad - 10, 10);
  
  ctx.restore();
}

function rotate() {
  const sectorIndex = getIndex();
  const sector = sectors[sectorIndex];
  ctx.canvas.style.transform = `rotate(${ang - PI / 2}rad)`;
  
  spinEl.textContent = !angVel ? "SPIN" : sector.label;
  spinEl.style.background = sector.color;
  spinEl.style.color = sector.text;
}

function frame() {
  if (!angVel && spinButtonClicked) {
    const finalSectorIndex = getIndex();
    const finalSector = sectors[finalSectorIndex];
    console.log(`Final sector index: ${finalSectorIndex}, label: ${finalSector.label}`);
    events.fire("spinEnd", finalSector);
    spinButtonClicked = false;
    return;
  }
  
  angVel *= friction;
  if (angVel < 0.002) angVel = 0;
  ang += angVel;
  ang %= TAU;
  rotate();
}

function engine() {
  frame();
  requestAnimationFrame(engine);
}

function init() {
  sectors.forEach(drawSector);
  rotate();
  engine();
  spinEl.addEventListener("click", () => {
    if (!angVel) angVel = rand(0.25, 0.45);
    spinButtonClicked = true;
  });
}

init();

events.addListener("spinEnd", (sector) => {
  console.log(`Woop! You won ${sector.label}`);
});
