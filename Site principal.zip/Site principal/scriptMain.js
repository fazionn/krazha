var dinero = '';
var nomeinp = ''
var senha = ''
var usuario = ''
var email = ''
var nomelog = ''
var senhalog = ''
const pedro = {nome:"pedro", username:"pedrao", email:"pedraodocabeção@gmail.com", senha:"pedrismo", saldo:1000000.00}
const ribas = {nome:"ribas", username:"nuciss", email:"manopussis@gmail.com", senha:"miamibeach", saldo:999999999.99}
const luca = {nome:"luca", username:"a", email:"lucasfaisao@gmail.com", senha:"a", saldo: 2.00}
const vitor = {nome:"vitor", username:"vitu", email:"profvitu@gmail.com", senha:"nota10", saldo:101010101010.00}
const cadastro1 = {nome:"", username:"", email:"", senha:"", saldo:0.00}
const usuarios = [pedro, luca, vitor, ribas];
var possivel = 0;
var missao = 0;
var indexsenha = -7;
var roletadas = 0;

function entrar() {
    document.getElementById("entrar").style.display = 'none';
    document.getElementById("login").style.display = 'block';
    document.getElementById("nomeent").focus();
    enterteste();
}

function cadastro() {
    document.getElementById("entrar").style.display = 'none';
    document.getElementById("preto").style.display = 'none';
    document.getElementById("jogo1").style.display = 'none';
    document.getElementById("jogo2").style.display = 'none';
    document.getElementById("jogo3").style.display = 'block';
    document.getElementById("adicionar").style.display = 'none';
    document.getElementById("saldo").style.display = 'none';
}

function confirmo() {
    document.getElementById("boasvindas").style.display = 'none';
    document.getElementById("preto").style.display = 'none';
}

function cadastradas2() {
    nomeinp = document.getElementById("nomeinp").value 
    senha = document.getElementById("senha").value
    usuario = document.getElementById("usuario").value
    email = document.getElementById("email").value
    if (nomeinp == '' || usuario == '' || email == '') {
        document.getElementById("deunao").style.display = 'none'
        document.getElementById("golpe").style.display = 'block'
        possivel = 1
    } else {
        for (let i = 0; i < usuarios.length; i++) {
            if (usuarios[i].username == usuario) {
                document.getElementById("golpe").style.display = 'none'
                document.getElementById("deunao").style.display = 'block'
                possivel = 1
                break
            } else {
                possivel = 2
            }
        }
    }
    if (possivel == 2) {
        document.getElementById("drug").innerHTML = nomeinp;
        cadastro1.nome = nomeinp;
        cadastro1.username = usuario;
        cadastro1.email = email;
        cadastro1.senha = senha;
        usuarios.push(cadastro1);
        document.getElementById("golpe").style.display = 'none'
        document.getElementById("preto").style.display = 'block'
        document.getElementById("deunao").style.display = 'none'
        document.getElementById("boasvindas2").style.display = 'block'
    }
}

function confirmo2() {
    document.getElementById("entrar").style.display = 'block';
    document.getElementById("boasvindas2").style.display = 'none';
    document.getElementById("jogo3").style.display = 'none';
    document.getElementById("jogo1").style.display = 'block';
    document.getElementById("jogo2").style.display = 'block';
    document.getElementById("adicionar").style.display = 'block';
    document.getElementById("saldo").style.display = 'block';
}

//seção login

function login() {
    nomelog = document.getElementById("nomeent").value;
    senhalog = document.getElementById("senhaent").value;
    if (nomelog == '' || senhalog == '') {
        document.getElementById("invalidao").style.display = 'block'
        document.getElementById("errou").style.display = 'none'
        missao = 1;
    } else {
        for (let j = 0; j < usuarios.length; j++) {
            if (nomelog == usuarios[j].username || nomelog == usuarios[j].email) {
                missao = 2;
                indexsenha = j;
                break;
            } else {
                document.getElementById("invalidao").style.display = 'none'
                document.getElementById("errou").style.display = 'block'
            }
        }
    } 
    if (missao == 2) {
        if (senhalog == usuarios[indexsenha].senha) {
            document.getElementById("preto").style.display = 'none'
            document.getElementById("login").style.display = 'none'
            document.getElementById("valorsaldo").innerHTML = usuarios[indexsenha].saldo.toFixed(2);
        } else {
            document.getElementById("invalidao").style.display = 'none'
            document.getElementById("errou").style.display = 'block'
        }
    }
}

//tentativa enter

function enterteste() {
    const input1 = document.getElementById("nomeent");
    const input2 = document.getElementById("senhaent");
    input1.addEventListener('keypress', function(enter) {
        var key = enter.which || enter.keyCode;
        if (key == 13) {
            document.getElementById("senhaent").focus();
        }
    }) 
    input2.addEventListener('keypress', function(enter2) {
        var key = enter2.which || enter2.keyCode;
        if (key == 13) {
            document.getElementById("loginbut").click();
        }
    })  
}   

//rolada magestral
